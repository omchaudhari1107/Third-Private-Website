var options = {
  strings: ["Full-Stack Dev", "Learner🔍", "Django Dev❤️", "Programmer🔥"],
  typeSpeed: 100,
  backSpeed: 100,
  backDelay: 1000,
  loop: true
};

var typed = new Typed('.multiple-filed', options);
